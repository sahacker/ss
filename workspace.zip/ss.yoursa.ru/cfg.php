<?php
    $dbtype='mysql';
    $db='sserv';
    $host='localhost';
    $user='sserv';
    $password='Qwer1234';
?>