<?php
require_once 'ssapilib.php';

$ssnet = new ssAPInet();

// echo $ssnet->NumberQry(1);

// $ssnet->Add(1, 'rnk', 'ООО "Рога и копыта 2"');

echo 'end!<br>';

unset($ssnet);


?>