<?php

return array(
	array(
		'username'=>'demo',
		'password'=>'$2a$10$JTJf6/XqC94rrOtzuF397OHa4mbmZrVTBOQCmYD9U.obZRUut4BoC',
		'email'=>'webmaster@example.com',
	),
);
